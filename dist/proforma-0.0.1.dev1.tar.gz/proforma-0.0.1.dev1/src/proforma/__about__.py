# SPDX-FileCopyrightText: 2024-present rjskene <rjskene83@gmail.com>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.1.dev1"
