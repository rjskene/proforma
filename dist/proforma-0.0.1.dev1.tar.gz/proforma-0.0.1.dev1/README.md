# proforma

[![PyPI - Version](https://img.shields.io/pypi/v/proforma.svg)](https://pypi.org/project/proforma)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/proforma.svg)](https://pypi.org/project/proforma)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install proforma
```

## License

`proforma` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
